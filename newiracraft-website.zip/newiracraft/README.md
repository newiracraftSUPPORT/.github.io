# newiracraft — Company Website

Static website for newiracraft, providing required legal and support pages for app store submissions.

## Pages

| Page | URL path | Purpose |
|------|----------|---------|
| Home | `/index.html` | Company landing page |
| Apps | `/apps.html` | App listings |
| Privacy Policy | `/privacy.html` | **Required by Google Play & App Store** |
| Terms of Service | `/terms.html` | **Required by Google Play & App Store** |
| Support | `/support.html` | **Required by Google Play & App Store** |

## Deploy to GitHub Pages

1. Create a new repo on GitHub named `newiracraft.github.io` (or any name if using a custom domain).
2. Push this folder to the `main` branch.
3. Go to repo **Settings → Pages**.
4. Set Source to **Deploy from a branch**, branch `main`, folder `/root`.
5. Save. Your site will be live at `https://yourusername.github.io/reponame`.

## Custom Domain

1. In repo **Settings → Pages → Custom domain**, enter your domain (e.g. `newiracraft.com`).
2. Add a `CNAME` file to this repo containing just your domain:
   ```
   newiracraft.com
   ```
3. At your DNS provider, add these records:
   - **A records** pointing to GitHub's IPs:
     ```
     185.199.108.153
     185.199.109.153
     185.199.110.153
     185.199.111.153
     ```
   - Or a **CNAME record**: `www` → `yourusername.github.io`

## Google Play / App Store — Where to Link

When submitting your app, use these URLs:

- **Privacy Policy:** `https://yourdomain.com/privacy.html`
- **Terms of Service:** `https://yourdomain.com/terms.html`
- **Support URL:** `https://yourdomain.com/support.html`

## Customise

- Update email addresses in `privacy.html`, `terms.html`, and `support.html` to your real addresses.
- Add new apps to `apps.html` as you launch them.
- Replace "Coming Soon" badge with App Store / Play Store links when live.
- Update the copyright year in each footer annually.
